#
# Copyright (C) 2023 Apple Inc. All rights reserved.
#
# https://github.com/apple/ml-dr/blob/main/LICENSE
# Reinforce Data, Multiply Impact: Improved Model Accuracy and Robustness with
# Dataset Reinforcement. , Faghri, F., Pouransari, H., Mehta, S., Farajtabar,
# M., Farhadi, A., Rastegari, M., & Tuzel, O., Proceedings of the IEEE/CVF
# International Conference on Computer Vision (ICCV), 2023.
#
