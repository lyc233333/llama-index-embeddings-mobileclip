# CHANGELOG

## [0.1.2] - 2024-2-15

- Remove incorrect one; resort back to lazy load of clip/torch
