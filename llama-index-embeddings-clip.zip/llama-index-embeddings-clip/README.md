# LlamaIndex Embeddings Integration: Clip
